package com.vaadin.book.examples.application.calc;

/** Business logic object for the Calculator example application. */
public class CalculatorModel {
    double current;
    double stored;
    double result;
    
    
}
