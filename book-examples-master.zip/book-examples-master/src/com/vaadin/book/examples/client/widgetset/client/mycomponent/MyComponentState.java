package com.vaadin.book.examples.client.widgetset.client.mycomponent;

import com.vaadin.shared.AbstractComponentState;

public class MyComponentState extends AbstractComponentState {
	private static final long serialVersionUID = -5149323568169128231L;

	//@DelegateToWidget
    public String text;
}